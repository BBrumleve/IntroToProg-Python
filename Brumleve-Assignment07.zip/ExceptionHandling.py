# -------------------------------------------------#
# Title: Exception Handling
# Dev:   BBrumleve
# Date:  Feb 24, 2019
# ChangeLog: (Who, When, What)
#   BBrumleve, 02/24/2019, Created script
#       to show how the program handles
#       exceptions entered
# -------------------------------------------------#

'''
This program loops through user-entered numbers to
determine if the user enters an integer.  Line 27
{n = int(n)} performs the integer check and if true,
the program "breaks" and ends.  If found false, the
exception is run, the user is notified the number they
entered is not an integer and the user is prompted to
re-enter a number that is an integer.  Once an integer
is entered and the loop is broken the user is printed
a final statement congratulating them of entering an
integer.
'''

while True:  # allows the user to continue entering numbers
    try:
        n = int(input("Please enter an integer: "))  # user enters a number to try
        n = int(n)  # number is checked to confirm it is an integer
        break  # if True, the number is an integer the program ends
    except ValueError:  # if False, the number is not an integer and enters this part of the program
        print("Your entry is not a valid integer.  Go ahead and try again.")  # statement if False and re-enter loop
print("Great! You entered an integer!")  # statement once an integer is entered and the program ends
