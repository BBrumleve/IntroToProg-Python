# -------------------------------------------------#
# Title: Pickling a Hero
# Dev:   BBrumleve
# Date:  Feb 24, 2019
# ChangeLog: (Who, When, What)
#   BBrumleve, 02/24/2019, Created script
#       to show how Python pickles data
# -------------------------------------------------#

import pickle # import the pickling module from Python

#--Data--
inventory = ["sword", "armor", "shield", "healing potion"]


#--Processing--
# Dump the data into a pickle
f = open("pickling.dat", "wb")  # writes the data to file as a pickle, note the "wb" to write binary
pickle.dump(inventory, f)  # picking the data
# Load the data back into the program from the pickle
f = open("pickling.dat", "rb")  # reads the pickled data in the file, note the "rb" to read binary
unpickledData = pickle.load(f)  # assigning the unpickled data to new object.
'''
Note the objects file names above are different ('unpickledData' versus 'inventory')
This indicates a different memory location is being used to store the unpickled data list.
'''
f.close()  # its good programming practice to close a file that's opened

#--I/O--
print("The Hero's inventory is pickled.")  # Notify user of pickling hero's inventory as a list
print("\nUnpickling the Hero's inventory looks like this: ")  # Notify user of unpickling hero's inventory as a list
print(unpickledData)  # Prints inventory back as a list from the unpickledData memory location
