#------------------------------------------------------------
#
# Title: ToDo File Script
# Dev: BBrumeleve
# Date: Feb 02, 2019
# Change Log: (Who, When, What)
#   (BBrumleve, Feb 9, 2019, ToDo File creation,
#       updating and saving)
#------------------------------------------------------------

'''
1. Create a text file called ToDo.txt using the following data:
    Clean House,low
    Pay Bills,high
2. When the program starts, load each row of data from the ToDo.txt\
    text file into a Python dictionary. (The data will be stored like\
    a row in a table.)
       Tip: You can use a for loop to read a single line of text from\
           the file and then place the data into a new dictionary object.
3. After you get the data in a Python dictionary, Add the new dictionary\
    “row” into a Python list object (now the data will be managed as a table).
4. Display the contents of the List to the user.
5. Allow the user to Add or Remove tasks from the list using numbered choices.\
    Something like this would work:
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
6. Save the data from the table into the Todo.txt file when the program exits.
'''

#Load each row of data from ToDo.txt into a Python Dictionary
toDoFile = open('/Users/brianbrumleve/Documents/PythonClass/Assignment05/ToDo.txt', 'r')

todoDict = {} # declaring the Dictionary
for line in toDoFile:
    row = line.split(',')
    task = row[0] # assigns the dictionary key
    priority = row[1].strip('\n') # assigns the dictionary value
    todoDict[task] = priority # This is the Dictionary, built from the file
print(todoDict) # print the Dictionary, built from the List
toDoFile.close() #it's proper to close the file you opened

#Step 2 - Display a menu of choices to the user
while (True):

    print("""
    Menu of Options
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save data to File 
    5) Exit Program
    """)

    choice = str(input('Which option would you like to perform? [1 to 5] - '))
    print() # adds a new line

    #Step 3 - Show the current items in the table
    if choice.strip() == '1':
        print(todoDict)
        print(input('\nPress the Enter key to go back to the Menu of Options.'))

    #Step 4 - Add a new item to the list/Table
    elif choice.strip() == '2':
        newTask = str(input('Please enter a new task: '))
        if newTask not in todoDict:
            newPriority = str(input('Please enter a priority: '))
            todoDict[newTask] = newPriority
        print(input('\nPress the Enter key to go back to the Menu of Options.'))


    #Step 5 - Remove a new item to the list/Table
    elif choice == '3':
        removeTask = input('Enter the task you want removed: ')
        if removeTask in todoDict:
            del todoDict[removeTask] # deletes the identified data value
            print('\nOkay,', '{',removeTask,'}', 'is deleted.')
        else: # this else statements ensures the entered data exists
            print('\nThe task does not exist, go back to\n'
                  'the Menu of Options and try again.')
        print(input('\nPress the Enter key to go back to the Menu of Options.'))

    #Step 6 - Save tasks to the ToDo.txt file
    elif choice == '4':
        toDoFile = open('/Users/brianbrumleve/Documents/PythonClass/Assignment05/ToDo.txt', 'a') # re-open ToDo.txt, this time to append
        key = newTask
        value = newPriority
        newList = [key+','+value] # gathers the added Dictionary key and value into a List for appending
        toDoFile.write(str(newList).strip('x[').strip(']')) # appends the new data to file
        toDoFile.close() # closes the new written file prior to re-starting the loop
        print('\n','Your data',todoDict,'are saved to file.')
        print(input('\nPress the Enter key to go back to the Menu of Options.'))
    elif choice == '5':
        break # exits the program
